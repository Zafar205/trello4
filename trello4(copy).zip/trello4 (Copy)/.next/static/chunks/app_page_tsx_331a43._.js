(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_331a43._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_331a43._.js",
  "chunks": [
    "static/chunks/node_modules_0f336b._.js",
    "static/chunks/_ac5582._.js"
  ],
  "source": "dynamic"
});
